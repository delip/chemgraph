"""
ChemGraph UI Package

This package contains the user interface components for ChemGraph including
the Streamlit web app and command-line interface.
"""

__version__ = "0.1.0"
